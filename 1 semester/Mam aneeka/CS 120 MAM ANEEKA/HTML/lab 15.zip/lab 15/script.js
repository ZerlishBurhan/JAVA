function change(){
document.getElementById('p1').innerHTML="i am chaged"

}
function displaydate(){
document.getElementById('paral').innerHTML=Date();

}
function mouseover(){

document.getElementById('div1').innerHTML="Thnk U";
}
function mouseout(){

    document.getElementById('div1').innerHTML="Zerlish burhan ";
    }
    function bulboff(){

        document.getElementById('bulb').src="bulboff.png"
    }
    function bulbon(){

        document.getElementById('bulb').src="bulbon.png"
    }
    function changestyle(){
        document.getElementById('p2').style.color="red"
    }