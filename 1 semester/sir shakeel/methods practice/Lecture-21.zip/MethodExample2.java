/*
  Lecture - 21
  Methods - returning methods
  01-03-2023
*/

class MethodExample2 {
 
  //    Return Type (int) --> Returning method
  static int sum(int n1, int n2) {
    int result = n1 + n2;
    return result;
  }//sum

  static int sum2(int n1, int n2) {
    return (n1 + n2);
  }//sum2

  static double sum3(double n1, double n2) {
    double result = n1 + n2;
    return result;
  }//sum3

  static double sum4(int n1, double n2) {
    double result = n1 + n2;
    return result;
  }//sum4

  static String sum5(double n1, int n2, String n3) {
    String result = n1 + n2 + n3;
    return result;
  }//sum5

  static boolean evaluation(boolean n1, boolean n2) {
    //boolean result = n1 && n2;
    boolean result = n1 || n2;
    return result;
  }//evaluation


  public static void main(String[] args) {

    // method call
    System.out.println("Result is: " + sum(5, -10));

    // better way
    int n1 = 5, n2 = -50;
    int result = sum(n1, n2);
    System.out.println("Result is: " + result);

    System.out.println(sum2(1, 2));
  
    double n3 = 0.01, n4 = -99.99;
    double n5 = sum3(n3, n4);
    System.out.println(n5);

    System.out.println(sum4(10, 10.99));

    String answer = sum5(0.01, 100, "Hello");
    System.out.println(answer);

    boolean b1 = 1 > 0;
    boolean b2 = 4 != 4;

    boolean output = evaluation(b1, b2);
    System.out.println(output);



  }//main

}//class