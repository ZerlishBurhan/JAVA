/*
  Lecture - 22
  Methods
  02-03-2023
*/

import java.util.Scanner;

class Methods1 {

  // a method that returns the larger of the two parameters 
  static int maximum(int n1, int n2) {
    int maxNumber = 0;
    
    if(n1 >= n2) {
      maxNumber = n1;
    } else {
      maxNumber = n2;
    }//if  

    return maxNumber;
    // System.out.println("After the return statement");
  }//maximum

  static int maximum2(int n1, int n2) {
    if(n1 >= n2) {
      return n1;
    } else {
      return n2;
    }//if  
    //return 0;
  }//maximum2

  static int eval(int a) {
    if(a >= 10) {
      return a;
    }//if
    return 0;	    
  }//eval

  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    int n1 = 0, n2 = 0;
 
    System.out.print("Enter 1st number: ");     
    n1 = input.nextInt();

    System.out.print("Enter 2nd number: ");     
    n2 = input.nextInt();

    int maxNumber = maximum(n1, n2);  
    System.out.println(maxNumber);

    System.out.println(maximum(n1, n2));

    maxNumber = maximum2(n1, n2);
    System.out.println(maxNumber);


  }//main

}//class