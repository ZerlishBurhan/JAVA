/*
  Lecture - 22
  Methods
  02-03-2023
*/

class Methods2 {

  static void changeValues(int n1, int n2) {
    n1 += 10;
    n2 *= 2;
    System.out.println(n1 + ", " + n2);
  }//changeValues

  public static void main(String[] args) {
    int n1 = 100, n2 = 500;
    System.out.println(n1 + ", " + n2);
   
    changeValues(n1, n2);
    System.out.println(n1 + ", " + n2);

  }//main

}//class