/*
  Lecture - 14
  Flag Controlled Loop Example
  02-Feb-2023
*/

import java.util.Scanner;

class FlagControlledLoopExample2 {

  public static void main(String[] args) {

    // flag: it is used to control our loop 
    boolean flag = true;    

    Scanner keyboard = new Scanner(System.in);

    /*
      take a number from the user and find the sum and the
      average of the inputs.
      Stop when the sum is equal or greater than 100
    */    

    double sum = 0.0, average = 0.0;
    int count = 0;

    System.out.print("Enter a number: ");
    int input = keyboard.nextInt();

    //while(flag == true) {
    while(flag) {
        // calculate the running sum
        sum += input;
        // count the number of values for calculating the average
        ++count;

      // stop when the sum is >= 100
      if(sum >= 100) {
	      flag = false;
        // remove the number that causes the sum to become 100 or more from the sum
        sum -= input;
      }//if

      if(flag) {
        System.out.print("Enter a number ");
        input = keyboard.nextInt();
      }//if

    }//while
    
    if(sum !=0 && sum < 100) {
      System.out.println("The sum of values is: " + sum);     
      average = sum / count;
      System.out.println("The average of values is: " + average);          
    } else {
      System.out.println("The sum of values is greater than or equal to 100, so no output");
    } //if


  }//main

}//class