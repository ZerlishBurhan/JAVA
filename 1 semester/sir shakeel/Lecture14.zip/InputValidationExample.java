/*
  Lecture - 14
  Input Validation Example 
  02-Feb-2023
*/

import java.util.Scanner; 

class InputValidationExample {

  public static void main(String[] args) {
  
    Scanner keyboard = new Scanner(System.in);      

    /*
      Ask a number from the user. If the number is positive, then 
      print that number. Otherwise, ask the user again for the
      input.
    */     

    // Step-1: ask the first value from the user
    System.out.print("Enter a positive integer: ");
    int input = keyboard.nextInt();

    // Step-2: Input validation: check if the number is +ve?
    while(input <= 0) {
      System.out.println("Your input is invalid!");
      System.out.print("Please enter a positive integer: ");
      input = keyboard.nextInt();   
    }//while

    // Step-3: Correct input	
    System.out.println("The value " + input + " is correct!"); 

  }//main

}//class