/*
  Lecture - 14
  Sentinel Value Example 
  02-Feb-2023
*/

import java.util.Scanner; 

class SentinelValueExample {

  public static void main(String[] args) {
  
    Scanner keyboard = new Scanner(System.in);      

    /*
      Ask a number from the user. We will calculate the sum 
      and the average of the all inputs, until -9999 is 
      entered as an input.
    */     

     int sum = 0, count = 0;
     double average = 0.0;

     final int SENTINEL = -9999;

    // Step-1: ask the first value from the user
    System.out.print("Enter an integer value (-9999 to stop): ");
    int input = keyboard.nextInt();

    // Step-2: Input validation: check if the number is +ve?
    while(input != SENTINEL) {
      sum += input;	
      ++count;	

      System.out.print("Enter an integer value (-9999 to stop): ");
      input = keyboard.nextInt();   
    }//while

    if(count > 0) {
      System.out.println("The sum is: " + sum); 
      average = sum / count;
      System.out.println("The average is: " + average); 
    } else {
      System.out.println("Average cannot be calculated for zero values");
    }//if

  }//main

}//class